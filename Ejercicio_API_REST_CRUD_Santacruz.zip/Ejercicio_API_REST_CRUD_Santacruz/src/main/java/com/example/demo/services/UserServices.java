package com.example.demo.services;
import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.functions.CompararUser;
import com.example.demo.functions.PrintUser;
import com.example.demo.models.UserModel;
import com.example.demo.repositories.*;

@Service
public class UserServices implements IUserServices {
    @Autowired
    UserRepository UserRepository;
   
    @Override
    public String TodosUsers(){
        ArrayList<UserModel> Lista;
        String Print="";
        try {
            Lista = (ArrayList<UserModel>) UserRepository.findAll();
            Print = new PrintUser().Print(Lista);
        } catch (Exception e) {
            //TODO: handle exception
            Print= "No existen Datos en el base";
        }
        return Print; 
    }

    @Override
    public String GuardarUser(UserModel usuario){
        ArrayList<UserModel> ListaTodos = (ArrayList<UserModel>) UserRepository.findAll();
        boolean aux = new CompararUser().Comparar(usuario, ListaTodos);

        if (aux==true) {
            UserModel usuarioAdd = UserRepository.save(usuario);
            ArrayList<UserModel> Lista = new ArrayList<>();
            Lista.add(usuarioAdd);
            String Print = new PrintUser().Print(Lista);
            return "Usuario añadido exitosamente!! \n\n"+Print;
        }else{
            return "El usuario con cedula: "+usuario.getCI()+" ya existe!!\nNo se añade el usuario";
        }
        
    }

    @Override
    public String BuscarXId(Long id){
        Optional<UserModel> Finduser;
        ArrayList<UserModel> Lista = new ArrayList<>();
        try {
            Finduser = UserRepository.findById(id); 
            Lista.add(Finduser.get());
            String Print = new PrintUser().Print(Lista);
            return Print;
        } catch (Exception e) {
            //TODO: handle exception
            return "No se encontró el usuario con ID: "+id+"!!";
        }
    }

    @Override
    public String findByNombre(String nombre){
        ArrayList<UserModel> Lista = new ArrayList<>();
        try {
            Lista = UserRepository.findByNombre(nombre); 
            String Print = new PrintUser().Print(Lista);
            return Print;
        } catch (Exception e) {
            //TODO: handle exception
            return "No se encontró usuarios con Nombre: "+nombre+"!!";
        }
    }

    @Override
    public String findByApellido(String Apellido){
        ArrayList<UserModel> Lista = new ArrayList<>();
        try {
            Lista = UserRepository.findByApellido(Apellido); 
            String Print = new PrintUser().Print(Lista);
            return Print;
        } catch (Exception e) {
            //TODO: handle exception
            return "No se encontró usuarios con Nombre: "+Apellido+"!!";
        }
    }

    @Override
    public String findByEdad(int Edad){
        ArrayList<UserModel> Lista = new ArrayList<>();
        try {
            Lista = UserRepository.findByEdad(Edad); 
            String Print = new PrintUser().Print(Lista);
            return Print;
        } catch (Exception e) {
            //TODO: handle exception
            return "No se encontró usuarios con Edad: "+Edad+"!!";
        }
    }

    @Override
    public String findByCi(int CI){
        ArrayList<UserModel> Lista = new ArrayList<>();
        try {
            Lista = UserRepository.findByCi(CI); 
            String Print = new PrintUser().Print(Lista);
            return Print;
        } catch (Exception e) {
            //TODO: handle exception
            return "No se encontró el usuario con N° cedula: "+CI+"!!";
        }
    }

    @Override
    public boolean EliminarXId(Long id){
        try {
            UserRepository.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

}
