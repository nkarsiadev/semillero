package com.example.demo.functions;
import java.util.ArrayList;
import com.example.demo.models.UserModel;

public class PrintUser {
    private ArrayList<UserModel> Lista;


    public ArrayList<UserModel> getLista() {
        return Lista;
    }


    public void setLista(ArrayList<UserModel> lista) {
        Lista = lista;
    }


    public String Print(ArrayList<UserModel> Lista){
        StringBuffer aux = new StringBuffer();
        String PrintTotal ="";
        for (int i = 0; i < Lista.size(); i++) {
            aux.append("ID=  ");
            aux.append(Lista.get(i).getId().toString());
            aux.append("\nNombre=  ");
            aux.append(Lista.get(i).getNombre().toString());
            aux.append("\nApellido=  ");
            aux.append(Lista.get(i).getApellido().toString());
            aux.append("\nEdad=  ");
            aux.append(Lista.get(i).getEdad());
            aux.append("\nN° Cedula=  ");
            aux.append(Lista.get(i).getCI());
            aux.append("\n\n");
        }

        PrintTotal = aux.toString();
        return PrintTotal;
    }
}
