package com.example.demo.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.models.UserModel;
import com.example.demo.services.*;


@RestController
@RequestMapping("/usuario")
public class UserController implements IUserController{
    @Autowired
    UserServices userServices;

    @Override
    @GetMapping()
    public String TodosUsers(){
        return userServices.TodosUsers();
    }

    @Override
    @PostMapping("/Guardar")
    public String GuardarUser(@RequestBody UserModel usuario){
        return this.userServices.GuardarUser(usuario);
    }

    @Override
    @GetMapping("/BuscarID")
    public String BuscarXId(@RequestParam Long ID){
        return this.userServices.BuscarXId(ID);
    }

    @Override
    @GetMapping("/BuscarNombre")
    public String findByNombre(@RequestParam String Nombre){
        return this.userServices.findByNombre(Nombre);
    }

    @Override
    @GetMapping("/BuscarApellido")
    public String findByApellido(@RequestParam String Apellido){
        return this.userServices.findByApellido(Apellido);
    }

    @Override
    @GetMapping("/BuscarEdad")
    public String findByEdad(@RequestParam int Edad){
        return this.userServices.findByEdad(Edad);
    }

    @Override
    @GetMapping("/BuscarCI")
    public String findByCi(@RequestParam int Ci){
        return this.userServices.findByCi(Ci);
    }

    @Override
    @DeleteMapping("/Borrar")
    public String EliminarXId(@RequestParam Long ID){
        boolean aux = this.userServices.EliminarXId(ID);
        if (aux==true) {
            return "Se eliminó el usuario: "+ID;

        }else{
            return "No se eliminó el usuario: "+ID;
        }

    }
}
