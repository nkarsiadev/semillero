package com.example.demo.Pruebas;

public class Pruebas2 {
    private String aux;
    private String aux2;

    public String getAux2() {
        return aux2;
    }

    public void setAux2(String aux2) {
        this.aux2 = aux2;
    }

    public String getAux() {
        return aux;
    }

    public void setAux(String aux) {
        this.aux = aux;
    }
    
    public void si (){
        if (aux==(String) "a") {
            aux2="Pruebas<T>";
        }
    }

    
}
