package com.example.demo.services;
import com.example.demo.models.UserModel;

public abstract interface IUserServices {
    public String TodosUsers();
    public String GuardarUser(UserModel usuario);
    public String BuscarXId(Long id);
    public String findByNombre(String nombre);
    public String findByApellido(String apellido);
    public String findByEdad(int edad);
    public String findByCi(int ci);
    public boolean EliminarXId(Long id);
}
