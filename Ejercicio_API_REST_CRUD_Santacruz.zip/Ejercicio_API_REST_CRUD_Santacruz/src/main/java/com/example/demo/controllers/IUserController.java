package com.example.demo.controllers;
import com.example.demo.models.UserModel;

public abstract interface IUserController {
    public abstract String TodosUsers();
    public abstract String GuardarUser(UserModel usuario);
    public abstract String BuscarXId(Long ID);
    public abstract String findByNombre(String Nombre);
    public abstract String findByApellido(String Apellido);
    public abstract String findByEdad(int Edad);
    public abstract String findByCi(int Ci);
    public abstract String EliminarXId(Long ID);

}
