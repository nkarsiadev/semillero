﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ApiGeneral.Models
{
    public partial class usuarioBPContext : DbContext
    {
        public usuarioBPContext()
        {
        }

        public usuarioBPContext(DbContextOptions<usuarioBPContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Cuentabp> Cuentabps { get; set; } = null!;
        public virtual DbSet<Tramite> Tramites { get; set; } = null!;
        public virtual DbSet<Usuario> Usuarios { get; set; } = null!;

        ////        protected override void onconfiguring(dbcontextoptionsbuilder optionsbuilder)
        ////        {
        ////            if (!optionsbuilder.isconfigured)
        ////            {
        ////#warning to protect potentially sensitive information in your connection string, you should move it out of source code. you can avoid scaffolding the connection string by using the name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. for more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?linkid=723263.
        ////                optionsbuilder.usesqlserver("data source=richi_laptop;initial catalog=apiback;integrated security=true");
        ////            }
        ////        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Cuentabp>(entity =>
            {
                entity.Property(e => e.Bpcuenta).IsFixedLength();

                entity.Property(e => e.Bpsaldo).IsFixedLength();

                entity.Property(e => e.Usucedula).IsFixedLength();

                entity.HasOne(d => d.UsucedulaNavigation)
                    .WithMany(p => p.Cuentabps)
                    .HasForeignKey(d => d.Usucedula)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CUENTABP_TIENE_USUARIO");
            });

            modelBuilder.Entity<Tramite>(entity =>
            {
                entity.Property(e => e.Tracodigo).IsFixedLength();

                entity.Property(e => e.Bpcuenta).IsFixedLength();

                entity.Property(e => e.Trarespaldo).IsFixedLength();

                entity.HasOne(d => d.BpcuentaNavigation)
                    .WithMany(p => p.Tramites)
                    .HasForeignKey(d => d.Bpcuenta)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TRAMITES_GENERA_CUENTABP");
            });

            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.Property(e => e.Usucedula).IsFixedLength();

                entity.Property(e => e.Usucelular).IsFixedLength();

                entity.Property(e => e.Usucorreo).IsFixedLength();

                entity.Property(e => e.Usunombre).IsFixedLength();
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
