﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ApiGeneral.Models
{
    [Table("TRAMITES")]
    [Index("Bpcuenta", Name = "GENERA_FK")]
    [Index("Tracodigo", Name = "TRAMITES_PK", IsUnique = true)]
    public partial class Tramite
    {
        [Key]
        [Column("TRACODIGO")]
        [StringLength(20)]
        [Unicode(false)]
        public string Tracodigo { get; set; } = null!;
        [Column("BPCUENTA")]
        [StringLength(15)]
        [Unicode(false)]
        public string Bpcuenta { get; set; } = null!;
        [Column("TRARESPALDO")]
        [StringLength(20)]
        [Unicode(false)]
        public string Trarespaldo { get; set; } = null!;

        [ForeignKey("Bpcuenta")]
        [InverseProperty("Tramites")]
        public virtual Cuentabp BpcuentaNavigation { get; set; } = null!;
    }
}
