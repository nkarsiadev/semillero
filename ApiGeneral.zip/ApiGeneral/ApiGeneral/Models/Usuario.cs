﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ApiGeneral.Models
{
    [Table("USUARIO")]
    [Index("Usucedula", Name = "USUARIO_PK", IsUnique = true)]
    public partial class Usuario
    {
        public Usuario()
        {
            Cuentabps = new HashSet<Cuentabp>();
        }

        [Key]
        [Column("USUCEDULA")]
        [StringLength(10)]
        [Unicode(false)]
        public string Usucedula { get; set; } = null!;
        [Column("USUNOMBRE")]
        [StringLength(30)]
        [Unicode(false)]
        public string Usunombre { get; set; } = null!;
        [Column("USUCELULAR")]
        [StringLength(12)]
        [Unicode(false)]
        public string Usucelular { get; set; } = null!;
        [Column("USUCORREO")]
        [StringLength(40)]
        [Unicode(false)]
        public string Usucorreo { get; set; } = null!;

        [InverseProperty("UsucedulaNavigation")]
        public virtual ICollection<Cuentabp> Cuentabps { get; set; }
    }
}
