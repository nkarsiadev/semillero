﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ApiGeneral.Models
{
    [Table("CUENTABP")]
    [Index("Bpcuenta", Name = "CUENTABP_PK", IsUnique = true)]
    [Index("Usucedula", Name = "TIENE_FK")]
    public partial class Cuentabp
    {
        public Cuentabp()
        {
            Tramites = new HashSet<Tramite>();
        }

        [Key]
        [Column("BPCUENTA")]
        [StringLength(15)]
        [Unicode(false)]
        public string Bpcuenta { get; set; } = null!;
        [Column("USUCEDULA")]
        [StringLength(10)]
        [Unicode(false)]
        public string Usucedula { get; set; } = null!;
        [Column("BPSALDO")]
        [StringLength(10)]
        [Unicode(false)]
        public string Bpsaldo { get; set; } = null!;

        [ForeignKey("Usucedula")]
        [InverseProperty("Cuentabps")]
        public virtual Usuario UsucedulaNavigation { get; set; } = null!;
        [InverseProperty("BpcuentaNavigation")]
        public virtual ICollection<Tramite> Tramites { get; set; }
    }
}
